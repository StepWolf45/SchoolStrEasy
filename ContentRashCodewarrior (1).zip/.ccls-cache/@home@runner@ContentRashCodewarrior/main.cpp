#include <iostream>
#include <string>
#include "str_easy.h"

using namespace std;

int main() {
	cout<< itc_even_place("FFFFrrr");
}